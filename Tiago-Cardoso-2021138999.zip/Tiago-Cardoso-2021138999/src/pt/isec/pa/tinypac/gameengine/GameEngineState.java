package pt.isec.pa.tinypac.gameengine;
public enum GameEngineState {READY, RUNNING, PAUSED}

